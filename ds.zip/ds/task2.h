
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
typedef struct adv{
  char Name[25];
   int  aID;
	char inf[1000];
struct adv *next;
} ADV ;
//void loop(FILE *fp2,ADV *adv);
ADV *root2;
ADV *insertAdv(ADV *adv)
{
	ADV *count;count=root2;	
	while(count->next!=NULL)
	{
	count=count->next;
	}
	count->next = adv;adv->next = NULL;    
}

  ADV *TaskTwo(FILE *fp2)
	{
		ADV *g;
		
		char h[50][50];
 

                 char a[1000];

		g=(ADV *) malloc(sizeof(ADV));	g->next=NULL;
                 root2=g;

		fp2=fopen("adv.txt","r");
               int i;
		while (fgets(a,sizeof(a),fp2)!=NULL )
		{
			int j=0,k=0;
		
			for( int i=0;a[i]!='\0';i++)
			{
				if(a[i]==',' || a[i]=='\n')
				{
					k=0;j=j+1;
					continue;
				}
				else {
				
					h[j][k]=a[i];
					k=k+1; 
                                            }
					//if(strlen(h[j][k]>h[
			h[j][k+1]='\0';	
			}

			
			g=(ADV*) malloc(sizeof(ADV));
                      strcpy(g->Name,h[1]);
                 g->aID=atoi(h[0]);
                 //atof;
                 strcpy(g->inf,h[2]);
           
                          insertAdv(g);
			a[1000]='\0';h[50][50]='\0';
		}fclose(fp2);}
void printAdvs(ADV *adv,int n){ if ( adv == NULL ) return;
            

          if(adv->aID==n){
	printf("NAME:%s\n aID:%d\n INF:%s\n\n\n",adv->Name,adv->aID,adv->inf);}
	printAdvs(adv->next,n);
}
void printAdvs2(ADV *adv){ if ( adv == NULL ) return;
            

     
	printf("NAME:%s\n aID:%d\n INF:%s\n\n\n",adv->Name,adv->aID,adv->inf);
	printAdvs2(adv->next);
}

void initialize	(char s[][100],int i){
char ch;
int k=0;
while(ch!='\n'){
scanf("%c",&ch);
s[i][k]=ch;
k++;
}
s[i][k+1]='\0';}
void registering2(FILE *fp2)
{int n;char s[100][100];
ADV *new_node,*current,*temp;

new_node=(ADV*)malloc(sizeof(ADV));
printf("enter ur id");
scanf("%d",&n);
new_node->aID=n;
int i=0;
printf("enter advertisement name");
scanf("%s",s[i]);
strcpy(new_node->Name,s[i]);
i++;
getchar();
printf("enter advertisement information");
//scanf("%s",s[i]);
initialize(s,i);
strcpy(new_node->inf,s[i]);
i++;
fp2=fopen("adv.txt","a+");
fprintf(fp2,"%d",n);
for(i=0;i<2;i++)
fprintf(fp2,",%s",s[i]);
fprintf(fp2,"\n");
fclose(fp2);
 new_node->next=NULL;
if(root2==NULL)
 {
   root2=new_node;
   current=new_node;
 }
 else
 {
   temp = root2;
     while(temp->next!=NULL)
     {
     temp = temp->next;
     }
   temp->next = new_node;
 }
//loop(fp2);
}

