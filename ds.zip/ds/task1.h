#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>

/*typedef struct hobbies{
  
   char game[15];
   char singing[3];
   char dancing[3];
   char adventure[3];
   char readingbooks[3];

} HOBBIES;*/

typedef struct profile{

  char Name[100];
   int  ID;
  char DOB[100];
  char Schooling[150];
  char College[100];
  char  hobbies[100];
struct profile *next;
} PROFILE ;
//void loop(FILE *fp,PROFILE *profile);
PROFILE *root;
//int n;
PROFILE *insertProfile(PROFILE *profile){
	PROFILE *count;count=root;
	
	while(count->next!=NULL)
{
	count=count->next;
}
	count->next = profile;profile->next = NULL;
    
}
  PROFILE *TaskOne(FILE *fp)
	{
		PROFILE *g;
		
		char h[100][1000];
 

                 char a[10000];

		g=(PROFILE *) malloc(sizeof(PROFILE));	g->next=NULL;
                 root=g;

		fp=fopen("names.txt","r");
               int i;
		while (fgets(a,sizeof(a),fp)!=NULL )
		{
			int j=0,k=0;
		
			for( int i=0;a[i]!='\0';i++)
			{
				if(a[i]==',' || a[i]=='\n')
				{
					k=0;j=j+1;
					continue;
				}
				else {
				
					h[j][k]=a[i];
					k=k+1; 
                                            }
					//if(strlen(h[j][k]>h[
			h[j][k+1]='\0';	
			}

			
			g=(PROFILE*) malloc(sizeof(PROFILE));
                      strcpy(g->Name,h[1]);
                 g->ID=atoi(h[0]);
                 //atof;
                 strcpy(g->DOB,h[2]);
                 //atof(h[2]);
            strcpy(g->Schooling,h[3]);//atof;//g->age=atof(h[5]);
                  //g->seat=atof(h[6]);
                  //atof;
                strcpy(g->College,h[4]);//g->fare=atof(h[8]);
                      //atof;
			strcpy(g->hobbies,h[5]);
                        //atof;
                          insertProfile(g);
			a[1000]='\0';h[100][1000]='\0';
		}fclose(fp);
//loop(fp);
	}
void printProfiles(PROFILE *profile,int n){ if ( profile == NULL ) return;
		/*fare=profile->fare;
               profile->fare=fare;*/
            //int n;

            

          if(profile->ID==n){
	printf("NAME:%s\n ID:%d\n DOB:%s\n SCHOOLING:%s\n COLLEGE:%s\n HOBBIES:%s\n\n",profile->Name,profile->ID,profile->DOB,profile->Schooling,profile->College,profile->hobbies);}
	printProfiles(profile->next,n);

}void printBookings2(PROFILE *profile){ if ( profile == NULL ) return;
		/*fare=profile->fare;
               profile->fare=fare;*/
            //int n;

            

          
	printf("NAME:%s\n ID:%d\n DOB:%s\n SCHOOLING:%s\n COLLEGE:%s\n HOBBIES:%s\n\n",profile->Name,profile->ID,profile->DOB,profile->Schooling,profile->College,profile->hobbies);
	printBookings2(profile->next);

}
void initialize2(char s[][100],int i){
char ch='z';
int k=0;
while(ch!='\n'){
scanf("%c",&ch);
s[i][k]=ch;
k++;
}
s[i][k+1]='\0';}
void registering(FILE *fp)
{int n;char s[100][100];
PROFILE *new_node,*current,*temp;

new_node=(PROFILE*)malloc(sizeof(PROFILE));
printf("enter ur id");
scanf("%d",&n);
new_node->ID=n;
int i=0;
printf("enter ur name");
scanf("%s",s[i]);
strcpy(new_node->Name,s[i]);
i++;
printf("enter ur dateofbirth in the form dd-jan-yyyy");
scanf("%s",s[i]);
strcpy(new_node->DOB,s[i]);
i++;
printf("enter ur schoolname");
scanf("%s",s[i]);
strcpy(new_node->Schooling,s[i]);
i++;
printf("enter ur collegename");
scanf("%s",s[i]);
strcpy(new_node->College,s[i]);
i++;
getchar();
printf("enter ur hobbies");
//scanf("%s",s[i]);
initialize2(s,i);
strcpy(new_node->hobbies,s[i]);
i++;
fp=fopen("names.txt","a+");
fprintf(fp,"%d",n);
for(i=0;i<5;i++)
fprintf(fp,",%s",s[i]);
fprintf(fp,"\n");
fclose(fp);
 new_node->next=NULL;
if(root==NULL)
 {
   root=new_node;
   current=new_node;
 }
 else
 {
   temp = root;
     while(temp->next!=NULL)
     {
     temp = temp->next;
     }
   temp->next = new_node;
 }
}

