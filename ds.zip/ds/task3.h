#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include"task1.h"
#include"task2.h"
void Taskthree(PROFILE *profile,ADV *adv,int input,char str2[])
{    
	int i=0,j=0,k=0,u=0,v=0,w=0;
	char str[1000],h[500][500],p[1000][1000],str4[1000];
	PROFILE *z;
	z=root;
	z=z->next;
	root=root->next;
	root2=root2->next;

        int count=0;
	while(root2!=NULL)
	{     
		strcpy(str,root2->inf);

		if(root2->aID==input||strcmp(root2->aName,str2)==0)
		{
			for( int i=0;str[i]!='\0';i++)
			{
				if(str[i]==' ' || str[i]=='\n')
				{
					k=0;j=j+1;
					continue;
				}
				else {

					h[j][k]=str[i];

					k=k+1; 
				}

				h[j][k+1]='\0';	
			}
			int l=j;str4[1000]='\0';p[100][1000]='\0';
			while(z!=NULL){
			           strcpy(str4,z->hobbies);
			         v=0;   
                              
                        for( int u=0;u<=strlen(str4);u++)
			{
				if(str4[u]==' ' || str4[u]=='\n'|| str4[u]=='\0')
				{
					p[v][w]=p[v][w+1]='\0';
					w=0;v++;
				}
				else {

                   		    p[v][w]=str4[u];

					w=w+1; 
				}

				//p[v][w+1]='\0';	
				
			} 
			       for(int m=0;m<v;m++)
					
				for( int m=0;m<v;m++){
				for(i=0;i<l;i++)
				{      
					if(strcmp(h[i],p[m])==0)
					{       
						printf("%s-------\n",z->Name); count++;                       
						break;
					}
				}
				}
				if(z->next!=NULL)
				{
					z=z->next;
					str4[1000]='\0';
					
				}
                                else
                                   break;
			}

			
		}  
                       if(root2->next!=NULL)
				root2=root2->next;
                       else
                                break;


	}
if(count==0)
printf("Sorry advertisement doesn't exist with ur given id.No search results found\n");
          }

