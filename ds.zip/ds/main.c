#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
//#include"task1.h"
//#include"task2.h"
#include"task3.h"
void loop(FILE *fp,PROFILE *profile,ADV *adv,FILE *fp2)
{printf("1.register\n2.login\n3.search\n4.exit\n");
int opt,opt2,n;
printf("enter ur option");
scanf("%d",&opt);
switch(opt)
{
case 1:printf("1.PROFILE\n2.ADVERTISEMENT\n");
       scanf("%d",&opt2);
       if(opt2==1)
       registering(fp);
       else
       registering2(fp2);
       printf("you have succesfully registered\n");
       loop(fp,profile,adv,fp2);
       break;
case 2:printf("1.PROFILE\n2.ADVERTISEMENT\n");
       TaskOne(fp);
       TaskTwo(fp2);
       scanf("%d",&opt2);
       printf("u have logged in\n");
       printf("enter an id which u want to search\n");
       if(opt2==1)
      {
       scanf("%d",&n);
       root=root->next;
       printProfiles(root,n);}
       else
        {
       scanf("%d",&n);
       root2=root2->next;
       printAdvs(root2,n);}
       loop(fp,profile,adv,fp2);
       break;
case 3:printf("search\n");
       TaskOne(fp);
       TaskTwo(fp2);
       printf("please enter advertisement id to search profiles\n");
       int input;
       scanf("%d",&input);
       Taskthree(root,root2,input);
       loop(fp,profile,adv,fp2);
case 4:break;
}}

                       
            
int main()
{
FILE *fp;
FILE *fp2;
PROFILE *profile;
ADV *adv;
loop(fp,profile,adv,fp2);
}
   
